# Word Lists

This is a collection of English words categorized by various themes.

## Guidelines

Words should be split across small categories, and as much as possible, only simple words should be included (news is better than newspaper, market is better than supermarket).